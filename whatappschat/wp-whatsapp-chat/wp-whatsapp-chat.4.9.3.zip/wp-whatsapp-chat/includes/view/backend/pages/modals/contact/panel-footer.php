<div class="media-toolbar-secondary"></div>
<div class="media-toolbar-primary search-form">
  <button id="submit" type="submit" class="media-modal-submit button button-primary media-button button-large" disabled="disabled"><?php esc_html_e('Save'); ?></button>

  <button type="button" class="media-modal-close button button-secondary media-button button-large" style="
          height: auto;
          float: none;
          position: inherit;
          padding: inherit;
          "><?php esc_html_e('Close'); ?></button>
</div>